use sakila;


SELECT * FROM actor WHERE first_name LIKE '%er%';