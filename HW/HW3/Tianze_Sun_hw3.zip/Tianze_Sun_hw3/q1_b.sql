use sakila;


SELECT amount FROM payment
ORDER BY amount DESC
LIMIT 1,1;